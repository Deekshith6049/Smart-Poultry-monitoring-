# 🐓 Smart Poultry Monitoring — ESP32‑CAM + YOLOv8 (Flask)

End‑to‑end, ready‑to‑deploy repository for **smart poultry monitoring**. ESP32‑CAM devices send frames to a Flask backend that runs **YOLOv8** to detect hens/chickens and stores results in **SQLite**. A simple web UI lets you test uploads, see registered devices and the latest detections.

## ✨ Features
- Flask API (`/api/frame`) for ESP32‑CAM to POST images
- YOLOv8 inference with configurable weights (default `yolov8n.pt`)
- Filters detections to poultry classes (hen/chicken/bird/rooster)
- Annotated image saving and simple dashboard (HTML/JS/CSS)
- SQLite persistence via SQLAlchemy
- One‑command local run; ready for Gunicorn deployment

## 📦 Repo Structure
```
smart-poultry-monitoring/
├── app.py
├── database.py
├── detectors/
│   └── yolo.py
├── tracking/
│   └── centroid_tracker.py   # optional helper (not wired by default)
├── templates/
│   └── index.html
├── static/
│   ├── css/styles.css
│   └── js/app.js
├── models/                   # place your YOLO weights here
├── uploads/                  # incoming sample frames (ignored by git)
├── data/annotated/           # saved annotated outputs
├── requirements.txt
├── config.example.toml
└── README.md
```

## 🔧 Prerequisites
- Python 3.10+ (recommended)
- (Optional) A YOLOv8 weights file trained on your poultry dataset, e.g. `models/best.pt`
- ESP32‑CAM sending JPEG frames (HTTP POST)

## 🚀 Quickstart (Local)
```bash
# 1) Create & activate venv
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate

# 2) Install deps
pip install -r requirements.txt

# 3) Configure (optional)
cp config.example.toml config.toml
# edit config.toml to point to your model weights in models/

# 4) Run (dev)
python app.py
# App at http://localhost:5000
```

Open `http://localhost:5000` and use the **Quick Test — Upload a Frame** form.

## 📡 ESP32‑CAM → Backend Integration
Have the ESP32‑CAM POST frames to `/api/frame` as `multipart/form-data`:
- `device_id`: e.g. `esp32cam-1`
- `device_name`: (optional) friendly label
- `image`: JPEG bytes

### Example cURL
```bash
curl -X POST http://localhost:5000/api/frame   -F device_id=esp32cam-1   -F device_name="Coop A Cam"   -F image=@sample.jpg
```

## 🧠 Model Weights
- Default tries `models/yolov8n.pt` (COCO). For best results, place your **fine‑tuned YOLOv8** weights at `models/best.pt` and set in `config.toml`:
```toml
[model]
weights = "models/best.pt"
confidence = 0.25
iou = 0.45
```

## 🗄️ Data & Storage
- SQLite DB at `poultry.db` (configurable)
- Annotated images saved in `data/annotated/`
- Latest detection per device: `GET /api/detection/<device_id>/latest`
- List devices: `GET /api/devices`

## 🧪 Testing Without ESP32‑CAM
Use the web UI or the cURL example to upload an image. The backend returns the number of hens detected and saves an annotated image if enabled.

## 🏭 Production (Gunicorn)
```bash
# Build DB once
python -c "from app import app, db; app.app_context().push(); db.create_all()"

# Run gunicorn (adjust workers)
gunicorn -b 0.0.0.0:5000 'app:app' --workers 2 --timeout 120
```

## 🔒 Environment & Config
The app reads `config.toml` if present; otherwise falls back to sane defaults. You can also set `CONFIG_PATH=/path/to/config.toml`.

## 📈 Roadmap
- Stream ingestion endpoint (chunked MJPEG)
- Tracker (ID per hen) via SORT/ByteTrack
- MQTT ingestion for low‑bandwidth telemetry
- Role‑based auth for multi‑farm dashboards

## 🙌 Acknowledgements
- YOLOv8 by Ultralytics
- ESP32‑CAM community examples
- Inspiration: your **Smart Poultry Monitoring** CSP using YOLOv8
