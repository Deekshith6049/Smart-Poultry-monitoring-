import os
from datetime import datetime, timezone
from PIL import Image
from flask import Flask, request, jsonify, send_from_directory, render_template, url_for
from flask_cors import CORS
from flask_migrate import Migrate
import toml

from database import db, Device, Detection
from detectors.yolo import YoloDetector

CONFIG_PATH = os.environ.get("CONFIG_PATH", "config.toml")
if os.path.exists(CONFIG_PATH):
    cfg = toml.load(CONFIG_PATH)
else:
    cfg = {
        "app": {"secret_key": "dev", "debug": True, "host": "0.0.0.0", "port": 5000},
        "model": {"weights": "models/yolov8n.pt", "confidence": 0.25, "iou": 0.45},
        "storage": {"database_uri": "sqlite:///poultry.db", "save_annotated": True, "save_dir": "data/annotated"},
        "devices": {},
    }

app = Flask(__name__, static_folder="static", template_folder="templates")
app.config["SECRET_KEY"] = cfg["app"].get("secret_key", "dev")
app.config["SQLALCHEMY_DATABASE_URI"] = cfg["storage"].get("database_uri", "sqlite:///poultry.db")
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

CORS(app)
db.init_app(app)
migrate = Migrate(app, db)

save_dir = cfg["storage"].get("save_dir", "data/annotated")
os.makedirs(save_dir, exist_ok=True)
os.makedirs("uploads", exist_ok=True)

detector = YoloDetector(
    weights_path=cfg["model"].get("weights", "models/yolov8n.pt"),
    conf=cfg["model"].get("confidence", 0.25),
    iou=cfg["model"].get("iou", 0.45),
)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/health")
def health():
    return jsonify(ok=True, model_loaded=detector.available)

def get_or_create_device(device_id: str, name: str = None):
    d = Device.query.filter_by(device_id=device_id).first()
    if d is None:
        d = Device(device_id=device_id, name=name)
        db.session.add(d)
        db.session.commit()
    else:
        if name and d.name != name:
            d.name = name
            db.session.commit()
    return d

@app.route("/api/frame", methods=["POST"])
def api_frame():
    device_id = request.form.get("device_id")
    device_name = request.form.get("device_name")
    file = request.files.get("image")
    if not device_id or not file:
        return jsonify(ok=False, error="device_id and image are required"), 400

    d = get_or_create_device(device_id, device_name)

    try:
        img = Image.open(file.stream).convert("RGB")
    except Exception as e:
        return jsonify(ok=False, error=f"Invalid image: {e}"), 400

    result = detector.infer(img)
    class_names = result.get("names", {})
    boxes = result["boxes"]
    classes = result["classes"]
    scores = result["scores"]

    accept_ids = [cid for cid, name in class_names.items() if name.lower() in ["hen", "chicken", "bird", "rooster"]]
    if accept_ids:
        filtered = [(b,c,s) for b,c,s in zip(boxes, classes, scores) if c in accept_ids]
        boxes = [f[0] for f in filtered]
        classes = [f[1] for f in filtered]
        scores = [f[2] for f in filtered]

    num_hens = len(boxes)

    annotated_path = None
    annotated_url = None
    if cfg["storage"].get("save_annotated", True):
        from PIL import Image as PILImage
        annotated_np = result["annotated"]
        annotated_img = PILImage.fromarray(annotated_np[:,:,::-1])  # BGR->RGB
        ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        fname = f"{device_id}_{ts}.jpg"
        fpath = os.path.join(save_dir, fname)
        annotated_img.save(fpath, quality=90)
        annotated_path = fpath
        annotated_url = url_for("serve_annotated", filename=fname, _external=False)

    det = Detection(
        device_id=d.id,
        num_hens=num_hens,
        raw={"boxes": boxes, "classes": classes, "scores": scores},
        image_path=annotated_path,
    )
    db.session.add(det)
    db.session.commit()

    return jsonify(ok=True, result={
        "num_hens": num_hens,
        "annotated_path": annotated_path,
        "annotated_url": annotated_url,
        "device_id": device_id
    })

@app.route("/annotated/<path:filename>")
def serve_annotated(filename):
    return send_from_directory(save_dir, filename)

@app.route("/api/devices")
def api_devices():
    items = Device.query.order_by(Device.created_at.desc()).all()
    return jsonify(devices=[{
        "device_id": x.device_id,
        "name": x.name,
        "created_at": x.created_at.isoformat()
    } for x in items])

@app.route("/api/detection/<device_id>/latest")
def api_latest_detection(device_id):
    d = Device.query.filter_by(device_id=device_id).first()
    if not d:
        return jsonify(ok=False, error="Unknown device_id"), 404
    det = Detection.query.filter_by(device_id=d.id).order_by(Detection.timestamp.desc()).first()
    if not det:
        return jsonify(ok=True, detection=None)
    annotated_url = None
    if det.image_path and os.path.exists(det.image_path):
        annotated_url = url_for("serve_annotated", filename=os.path.basename(det.image_path), _external=False)
    return jsonify(ok=True, detection={
        "timestamp": det.timestamp.isoformat(),
        "num_hens": det.num_hens,
        "annotated_url": annotated_url
    })

if __name__ == "__main__":
    with app.app_context():
        db.create_all()
    app.run(host=cfg["app"].get("host","0.0.0.0"), port=cfg["app"].get("port",5000), debug=cfg["app"].get("debug",True))
