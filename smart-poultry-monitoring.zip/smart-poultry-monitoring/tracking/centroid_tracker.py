# Minimal centroid tracker to assign persistent IDs within a session
# Not a replacement for SORT/ByteTrack, but works for demo purposes.
from scipy.spatial.distance import cdist
import numpy as np

class CentroidTracker:
    def __init__(self, max_distance=50):
        self.next_id = 1
        self.objects = {}  # id -> centroid
        self.max_distance = max_distance

    def update(self, boxes_xyxy):
        # boxes: list of [x1,y1,x2,y2]
        centroids = np.array([[(x1+x2)/2, (y1+y2)/2] for x1,y1,x2,y2 in boxes_xyxy], dtype=float)
        if len(self.objects) == 0:
            ordered_ids = []
            for c in centroids:
                self.objects[self.next_id] = c
                ordered_ids.append(self.next_id)
                self.next_id += 1
            return ordered_ids

        obj_ids = list(self.objects.keys())
        obj_centroids = np.array([self.objects[i] for i in obj_ids])
        if len(centroids)==0:
            return []
        D = cdist(obj_centroids, centroids)
        assignments = {}
        used_cols = set()
        flat_sorted = np.argsort(D, axis=None)
        for r in flat_sorted:
            i = r // D.shape[1]
            j = r % D.shape[1]
            if i in assignments or j in used_cols:
                continue
            if D[i,j] <= self.max_distance:
                assignments[i] = j
                used_cols.add(j)
        # Update matched
        for i, j in assignments.items():
            oid = obj_ids[i]
            self.objects[oid] = centroids[j]
        # New detections
        new_cols = [j for j in range(len(centroids)) if j not in used_cols]
        new_ids = []
        for j in new_cols:
            oid = self.next_id
            self.objects[oid] = centroids[j]
            new_ids.append(oid)
            self.next_id += 1
        # Return IDs for current centroids order
        id_map = {v:k for k,v in assignments.items()}
        ordered_ids = []
        for idx in range(len(centroids)):
            if idx in id_map:
                ordered_ids.append(id_map[idx])
            else:
                ordered_ids.append(new_ids.pop(0))
        return ordered_ids
