async function uploadFrame(form) {
  const formData = new FormData(form);
  const res = await fetch('/api/frame', { method: 'POST', body: formData });
  const data = await res.json();
  const out = document.getElementById('upload-output');
  if (data.ok) {
    out.textContent = `Detected ${data.result.num_hens} hens. Saved: ${data.result.annotated_path || 'no'}`;
    if (data.result.annotated_url) {
      const img = document.getElementById('annotated-img');
      img.src = data.result.annotated_url + '?t=' + Date.now();
      img.style.display = 'block';
    }
  } else {
    out.textContent = 'Error: ' + data.error;
  }
}

async function refreshDevices() {
  const res = await fetch('/api/devices');
  const data = await res.json();
  const tbody = document.getElementById('devices-tbody');
  tbody.innerHTML = '';
  data.devices.forEach(d => {
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${d.device_id}</td><td>${d.name || '-'}</td><td>${new Date(d.created_at).toLocaleString()}</td>`;
    tbody.appendChild(tr);
  });
}

async function refreshLatest() {
  const deviceId = document.getElementById('query-device').value.trim();
  if (!deviceId) return;
  const res = await fetch(`/api/detection/${encodeURIComponent(deviceId)}/latest`);
  const data = await res.json();
  const el = document.getElementById('latest-output');
  if (data.ok && data.detection) {
    el.textContent = `Latest: ${data.detection.num_hens} hens at ${new Date(data.detection.timestamp).toLocaleString()}`;
    const img = document.getElementById('latest-img');
    if (data.detection.annotated_url) {
      img.src = data.detection.annotated_url + '?t=' + Date.now();
      img.style.display = 'block';
    }
  } else {
    el.textContent = data.error || 'No data';
  }
}

document.addEventListener('DOMContentLoaded', () => {
  refreshDevices();
  document.getElementById('upload-form').addEventListener('submit', (e) => {
    e.preventDefault();
    uploadFrame(e.target);
  });
  document.getElementById('refresh-btn').addEventListener('click', refreshDevices);
  document.getElementById('latest-btn').addEventListener('click', refreshLatest);
});
