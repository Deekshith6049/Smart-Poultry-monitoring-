import os
from typing import Dict, Any
from PIL import Image
import numpy as np

try:
    from ultralytics import YOLO
except Exception as e:
    YOLO = None

class YoloDetector:
    def __init__(self, weights_path: str = "models/yolov8n.pt", conf: float = 0.25, iou: float = 0.45):
        self.available = False
        self.names = {}
        self.model = None
        self.conf = conf
        self.iou = iou
        if YOLO is None:
            print("[WARN] ultralytics not available in this environment.")
            return
        if not os.path.exists(weights_path):
            print(f"[WARN] Weights not found at {weights_path}. Ultralytics may attempt to download yolov8n.pt at first run.")
        try:
            self.model = YOLO(weights_path if os.path.exists(weights_path) else "yolov8n.pt")
            self.names = self.model.names
            self.available = True
        except Exception as e:
            print("[ERROR] Failed to load YOLO model:", e)

    def infer(self, image: Image.Image) -> Dict[str, Any]:
        \"\"\"
        Returns dict with 'boxes' (xyxy), 'classes', 'scores', 'names', 'annotated' (numpy array)
        \"\"\"
        if not self.available:
            return {\"boxes\": [], \"classes\": [], \"scores\": [], \"names\": {}, \"annotated\": np.array(image)}
        results = self.model.predict(image, conf=self.conf, iou=self.iou, verbose=False)
        r = results[0]
        boxes = r.boxes.xyxy.cpu().numpy().tolist() if r.boxes is not None else []
        classes = r.boxes.cls.cpu().numpy().astype(int).tolist() if r.boxes is not None else []
        scores = r.boxes.conf.cpu().numpy().tolist() if r.boxes is not None else []
        annotated = r.plot()  # numpy array BGR
        return {\"boxes\": boxes, \"classes\": classes, \"scores\": scores, \"names\": self.names, \"annotated\": annotated}
